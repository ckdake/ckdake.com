#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>
#include <time.h>

#define BUFFER_LENGTH 256
#define MAX_ENTRIES 255
#define NAMESERVER "localhost"
#define NAMESERVER_PORT 8080

int numentries = 0;

char *symbols[MAX_ENTRIES];
char *servers[MAX_ENTRIES];
int ports[MAX_ENTRIES];
char *filters[MAX_ENTRIES];

int messagecount = 0;
pthread_mutex_t countlock;

pthread_t threads[MAX_ENTRIES];

int lookup(char* symbol, char buffer[]) {

	int sockfd;
	struct sockaddr_in serv_addr;
	struct hostent *server;

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("ERROR opening socket\n");
		return 0;
	}

	if ((server = gethostbyname(NAMESERVER)) == NULL) {
		printf("ERROR no such host\n");
		return 0;
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	bcopy((char *)server->h_addr,
			(char *)&serv_addr.sin_addr.s_addr,
			server->h_length);
	serv_addr.sin_port = htons(NAMESERVER_PORT);

	if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
		printf("ERROR connecting\n");
		return 0;
	}

	if (write(sockfd, symbol, strlen(symbol)) < 0) {
		printf("ERROR writing to socket\n");
		return 0;
	} 

	bzero(buffer, BUFFER_LENGTH);
	if (read(sockfd, buffer, BUFFER_LENGTH-1) < 0) {
		printf("ERROR reading from socket\n");
		return 0;
	}
	if (strlen(buffer) > 0 ){
		return 1;
	} else {
		return 0;
	}
}


void * run_client_thread(void * id) {


	printf("starting thread for %s\n", symbols[(int)id]);
	int sockfd;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char buffer[BUFFER_LENGTH];

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("ERROR opening socket\n");
		pthread_exit(NULL);
	}

	if ((server = gethostbyname(servers[(int)id])) == NULL) {
		printf("ERROR no such host\n");
		pthread_exit(NULL);
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	bcopy((char *)server->h_addr,
			(char *)&serv_addr.sin_addr.s_addr,
			server->h_length);
	serv_addr.sin_port = htons(ports[(int)id]);

	if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
		printf("ERROR connecting\n");
		pthread_exit(NULL);
	}

	bzero(buffer, BUFFER_LENGTH);
	memcpy(buffer, symbols[(int)id], strlen(symbols[(int)id]));
	buffer[strlen(symbols[(int)id])] = ':';
	memcpy(buffer + strlen(symbols[(int)id] + 1), filters[(int)id], strlen(filters[(int)id]));
	printf("sending: %s\n", buffer);
	if (write(sockfd, buffer, strlen(buffer)) < 0) {
		printf("ERROR writing to socket\n");
		pthread_exit(NULL);
	}

	bzero(buffer, BUFFER_LENGTH);
	while (read(sockfd, buffer, BUFFER_LENGTH-1) >= 0) {
		printf("%s(%ld):%s\n", symbols[(int)id], time(NULL), buffer);
		pthread_mutex_lock(&countlock);
		messagecount++;
		pthread_mutex_unlock(&countlock);
		bzero(buffer, BUFFER_LENGTH);
	}

	printf("ending thread for %s\n", symbols[(int)id]);
	pthread_exit(NULL);
}

int main(int argc, char * argv[]) {
	
	int i, j;
	char * symbol = "";
	char * filter = "";
	char * server = "";
	char buf[BUFFER_LENGTH];
	
	for (i = 1; i < argc; i++) {
		bzero(buf,BUFFER_LENGTH-1);

		memcpy(buf, "L:", 2);

		for (j = 0; j < strlen(argv[i]); j++) {
			if (argv[i][j] == ':') {
				symbol = malloc(j + 2);
				bzero(symbol, j + 2);
				memcpy(symbol, argv[i], j);
				memcpy(buf + 2, symbol, strlen(symbol));
				printf("stored symbol: %s\n", symbol);
				
				filter = malloc(strlen(argv[i]) - j + 2);
				bzero(filter, strlen(argv[i]) - j + 2);
				memcpy(filter, argv[i] + j + 1, strlen(argv[i]) - j);
				printf("stored filter: %s\n", filter);
			}
		}

		memcpy(buf + 2 + j, "\n", 2);

		if (lookup(buf, (char *)&buf)) {
			for (j = 0; j < strlen(buf); j++) {
				if (buf[j] == ':') {
					server = malloc(j + 2);
					bzero(server, j + 2);
					memcpy(server, buf, j);
					servers[numentries] = server;
					ports[numentries] = atoi(buf + j + 1);
					printf("lookup results: %s:%d\n", 
						servers[numentries], ports[numentries]);
				}
			}
			symbols[numentries] = symbol;
			filters[numentries] = filter;
			numentries++;
		} else {
			printf("Lookup (%s) failed!\n", symbol);
			free(symbol);
			free(filter);
		}
	}

	pthread_mutex_init(&countlock, NULL);
	for (i = 0; i < numentries; i++) {
		pthread_create(&threads[i], NULL, run_client_thread, (void *)i);
	}
	for (i = 0; i < numentries; i++) {
		pthread_join(threads[i], NULL);
	}
	printf("in %ld seconds on %d active servers: %d notices\n", clock()/CLOCKS_PER_SEC, numentries, messagecount);

	for (i = 0; i < numentries; i++) {
		free(symbols[i]);
		free(filters[i]);
		free(servers[i]);
	}

	return 0;
}


