#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUFFER_LENGTH 256
#define MAX_ENTRIES 255


/**
 * IMPORTANT:
 * - there is no way to delete an entry
 * - if you register some key more than once, the first value will always be the answer
 * - only up to MAX_ENTRIES can be registered
 * - depends on queries being of the following formats:
 *   R:SYMBOL:hostname.example.com     -> this registers a service
 *   L:SYMBOL	-> this returns the host name of this service
 *   Q 	-> quits the server (disable this in a prod environment!)
 *
 */

int numentries = 0;
char *keys[MAX_ENTRIES];
char *values[MAX_ENTRIES];

void error(char *msg) {
	perror(msg);
	exit(1);
}

char * do_lookup(char * key) {
	int i;
	
	for (i=0; i < numentries; i++) {
		if (!strncmp(key, keys[i], strlen(keys[i]))) {
			return values[i];
		}
	}
	
	return "";
}

int do_register(char * registerstring) {
	int i;
	char *key;
	char *value;

	//find the : separator
	for (i = 0; i < strlen(registerstring); i++) {
		if (registerstring[i] == ':') {

            // get subject 
			key = malloc(i+1);
			bzero(key,i+1);
			memcpy(key,registerstring,i);

            // get value
			value = malloc(strlen(registerstring) - i + 1);
			bzero(value,strlen(registerstring) - i + 1);
			memcpy(value, registerstring + i + 1, strlen(registerstring) - i - 1);
			bzero(value + strlen(value) - 1, 1);

            // save entry
			keys[numentries] = key;
			values[numentries] = value;
			numentries++;
			printf("registered (%d): %s on %s\n", numentries, key, value);
			return 1;
		}
	}
	
	return 0;

}

void clean_and_quit(int sockfd, int newsockfd) {
	int i;

	for (i = 0; i < numentries; i++) {
		free(keys[i]);
		free(values[i]);
	}

	close(newsockfd);
	close(sockfd);
	exit(0);
}

int main(int argc, char * argv[]) {

	int sockfd, newsockfd;
	char buffer[BUFFER_LENGTH];
	char *message = "hmm";
	struct sockaddr_in serv_addr;

	if (argc < 2) {
		fprintf(stderr,"ERROR, no port provided\n");
		exit(1);
	}

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		error("ERROR opening socket");
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(atoi(argv[1]));
	
	if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)  {
		error("ERROR on binding");
	}

	listen(sockfd,5);
	
	while (1) {
		if ((newsockfd = accept(sockfd, NULL, NULL)) < 0) {
			error("ERROR on accept");
		}

		bzero(buffer,BUFFER_LENGTH);

		if (read(newsockfd,buffer, BUFFER_LENGTH - 1) < 0) {
			error("ERROR reading from socket");
		}

		switch (buffer[0]) {
		case 'L':
			printf("(lookup) %s\n", buffer);
			message = do_lookup(buffer+2);
			break;
		case 'R':
			printf("(register) %s\n", buffer);
			if (do_register(buffer+2)) {
				message = "OK\n";
			} else {
				message = "FAIL\n";
			}
			break;
		case 'Q':
			printf("(quitting!)\n");
			clean_and_quit(newsockfd, sockfd);
			break;
		default:
			printf("(unknown!) %s\n", buffer);
			message = "WTF are you trying to do?\n";
		}

		if(write(newsockfd, message, strlen(message)) < 0) {
			error("ERROR writing to socket");
		}

		close(newsockfd);
	}
	close(sockfd);
	return 0; 
}


