using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;

namespace AdResetter
{
	[RunInstaller(true)]
	public class AdResetterInstaller: System.Configuration.Install.Installer
	{
		private System.ServiceProcess.ServiceProcessInstaller processInstaller;
		private System.ServiceProcess.ServiceInstaller serviceInstaller;
		private System.ComponentModel.Container components = null;

		public AdResetterInstaller()
		{
			InitializeComponent();
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			this.processInstaller = new System.ServiceProcess.ServiceProcessInstaller();
			this.serviceInstaller = new System.ServiceProcess.ServiceInstaller();

			this.processInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
			this.processInstaller.Password = null;
			this.processInstaller.Username = null;

			this.serviceInstaller.DisplayName = "AdResetterRemotingService";
			this.serviceInstaller.ServiceName = "AdResetterRemotingService";
			this.serviceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;

			this.Installers.AddRange(new System.Configuration.Install.Installer[] {
																					  this.processInstaller,
																					  this.serviceInstaller});
		}
	}
}
